import java.util.Scanner;
public class Stone {

    //attributes
    private double weight;
    private String material;
    private int numStones;
    private int wall;
    Scanner ask = new Scanner(System.in);

    //methods
    public Stone() {
        numStones = 50;
        weight = 4.5;
        material = "brick";
    }
    public Stone(int n) {
        numStones = n;
        weight = 4.5;
        material = "brick";
    }
    public Stone(int n, int w) {
        numStones = n;
        weight = w;
        material = "brick";
    }
    public Stone(int n, double w, String m) {
        numStones = n;
        weight = w;
        material = m;
    }

    public void stoneCheck()
        {
        System.out.println("You are holding " + numStones + " stones now. They are made of " + material + " and weigh " + weight + " lbs each.");
        }
    public void wallCheck()
        {
        System.out.println("The wall is made of " + wall + " stones now.");
        }

    public void grabStone()
        {
        System.out.println("How many stones do you want to grab?");
        int grab = ask.nextInt();
        numStones += grab;
        stoneCheck();

        }
    public void buildWall()
        {
        wall += numStones;
        System.out.println("You add " + numStones + " stones to the wall.");
        numStones = 0;
        wallCheck();
            System.out.println();

        }
}
